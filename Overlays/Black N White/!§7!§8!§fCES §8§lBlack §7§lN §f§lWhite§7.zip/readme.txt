OptiFine is required for most pack features to work

Connected Textures must be set to Fast or Fancy in Video Settings -> Quality

Credit to ApplePies#7974 for the cit to Black and White leather